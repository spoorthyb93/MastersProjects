package PushRelabel;

public enum PREdgeType {
	Graph,
	Resudual
}
