package PushRelabel;

import java.util.LinkedList;

public class PRVertexData {
	public int height;
	public int excessFlow;
	
	public PRVertexData()
	{
		this.height = 0;
		this.excessFlow = 0;
	}
}
